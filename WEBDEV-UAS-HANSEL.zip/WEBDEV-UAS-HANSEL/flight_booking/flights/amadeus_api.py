import requests
from datetime import datetime, timedelta
from django.conf import settings
from django.core.cache import cache

class AmadeusAPI:
    def __init__(self):
        self.api_key = settings.AMADEUS_API_KEY
        self.api_secret = settings.AMADEUS_API_SECRET
        self.base_url = settings.AMADEUS_API_URL
        self.access_token = None
    
    def get_access_token(self):
        """Mendapatkan access token dari Amadeus API"""
        # Cek cache terlebih dahulu
        cached_token = cache.get('amadeus_access_token')
        if cached_token:
            return cached_token
        
        url = f"{self.base_url}/v1/security/oauth2/token"
        headers = {
            'Content-Type': 'application/x-www-form-urlencoded'
        }
        data = {
            'grant_type': 'client_credentials',
            'client_id': self.api_key,
            'client_secret': self.api_secret
        }
        
        try:
            response = requests.post(url, headers=headers, data=data)
            response.raise_for_status()
            token_data = response.json()
            access_token = token_data['access_token']
            
            # Simpan token di cache selama 25 menit (token berlaku 30 menit)
            cache.set('amadeus_access_token', access_token, 1500)
            
            return access_token
        except requests.exceptions.RequestException as e:
            print(f"Error getting access token: {str(e)}")
            return None
    
    def search_flights(self, origin, destination, departure_date, return_date=None, adults=1):
        """Mencari penerbangan berdasarkan kriteria"""
        token = self.get_access_token()
        if not token:
            return {'error': 'Gagal mendapatkan access token'}
        
        url = f"{self.base_url}/v2/shopping/flight-offers"
        headers = {
            'Authorization': f'Bearer {token}'
        }
        
        params = {
            'originLocationCode': origin.upper(),
            'destinationLocationCode': destination.upper(),
            'departureDate': departure_date,
            'adults': adults,
            'max': 10,
            'currencyCode': 'IDR'
        }
        
        if return_date:
            params['returnDate'] = return_date
        
        try:
            response = requests.get(url, headers=headers, params=params)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            error_message = str(e)
            if hasattr(e, 'response') and e.response is not None:
                try:
                    error_data = e.response.json()
                    error_message = error_data.get('errors', [{}])[0].get('detail', str(e))
                except:
                    pass
            return {'error': error_message}
    
    def get_flight_price(self, flight_offer):
        """Konfirmasi harga penerbangan"""
        token = self.get_access_token()
        if not token:
            return {'error': 'Gagal mendapatkan access token'}
        
        url = f"{self.base_url}/v1/shopping/flight-offers/pricing"
        headers = {
            'Authorization': f'Bearer {token}',
            'Content-Type': 'application/json'
        }
        
        data = {
            'data': {
                'type': 'flight-offers-pricing',
                'flightOffers': [flight_offer]
            }
        }
        
        try:
            response = requests.post(url, headers=headers, json=data)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            return {'error': str(e)}
    
    def create_booking(self, flight_offer, traveler_info):
        """Membuat booking penerbangan"""
        token = self.get_access_token()
        if not token:
            return {'error': 'Gagal mendapatkan access token'}
        
        url = f"{self.base_url}/v1/booking/flight-orders"
        headers = {
            'Authorization': f'Bearer {token}',
            'Content-Type': 'application/json'
        }
        
        # Format data sesuai Amadeus API
        data = {
            'data': {
                'type': 'flight-order',
                'flightOffers': [flight_offer],
                'travelers': [
                    {
                        'id': '1',
                        'dateOfBirth': '1990-01-01',
                        'name': {
                            'firstName': traveler_info.get('first_name', ''),
                            'lastName': traveler_info.get('last_name', '')
                        },
                        'gender': 'MALE',
                        'contact': {
                            'emailAddress': traveler_info.get('email', 'test@example.com'),
                            'phones': [
                                {
                                    'deviceType': 'MOBILE',
                                    'countryCallingCode': '62',
                                    'number': '81234567890'
                                }
                            ]
                        },
                        'documents': [
                            {
                                'documentType': 'PASSPORT',
                                'number': traveler_info.get('passport_number', ''),
                                'expiryDate': '2030-12-31',
                                'issuanceCountry': 'ID',
                                'nationality': 'ID',
                                'holder': True
                            }
                        ]
                    }
                ]
            }
        }
        
        try:
            response = requests.post(url, headers=headers, json=data)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            error_message = str(e)
            if hasattr(e, 'response') and e.response is not None:
                try:
                    error_data = e.response.json()
                    error_message = error_data.get('errors', [{}])[0].get('detail', str(e))
                except:
                    pass
            return {'error': error_message}