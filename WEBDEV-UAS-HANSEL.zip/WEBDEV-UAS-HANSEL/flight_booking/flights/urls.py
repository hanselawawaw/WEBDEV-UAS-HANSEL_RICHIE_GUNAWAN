from django.urls import path
from . import views

urlpatterns = [
    path('', views.search_flight, name='search_flight'),
    path('results/', views.flight_results, name='flight_results'),
    path('booking/', views.flight_booking, name='flight_booking'),
    path('confirmation/', views.booking_confirmation, name='booking_confirmation'),
]