from django.db import models
from django.utils import timezone

class Booking(models.Model):
    booking_reference = models.CharField(max_length=50, unique=True)
    passenger_name = models.CharField(max_length=200)
    passport_number = models.CharField(max_length=50)
    origin = models.CharField(max_length=3)
    destination = models.CharField(max_length=3)
    departure_date = models.DateField()
    return_date = models.DateField(null=True, blank=True)
    flight_data = models.JSONField()
    total_price = models.DecimalField(max_digits=10, decimal_places=2)
    currency = models.CharField(max_length=3, default='IDR')
    created_at = models.DateTimeField(auto_now_add=True)
    status = models.CharField(max_length=20, default='pending')
    
    class Meta:
        ordering = ['-created_at']
    
    def __str__(self):
        return f"{self.booking_reference} - {self.passenger_name}"