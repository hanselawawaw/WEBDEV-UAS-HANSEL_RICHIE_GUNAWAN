from django.shortcuts import render, redirect
from django.contrib import messages
from django.views.decorators.http import require_http_methods
from .amadeus_api import AmadeusAPI
from .models import Booking
import json
from datetime import datetime
import uuid

def search_flight(request):
    """Halaman pencarian penerbangan"""
    return render(request, 'search_flight.html')

@require_http_methods(["POST"])
def flight_results(request):
    """Halaman hasil pencarian penerbangan"""
    origin = request.POST.get('origin', '').strip()
    destination = request.POST.get('destination', '').strip()
    departure_date = request.POST.get('departure_date', '').strip()
    return_date = request.POST.get('return_date', '').strip()
    trip_type = request.POST.get('trip_type', 'oneway')
    
    # Validasi input
    if not all([origin, destination, departure_date]):
        messages.error(request, 'Mohon lengkapi semua field yang diperlukan')
        return redirect('search_flight')
    
    # Validasi kode IATA (3 huruf)
    if len(origin) != 3 or len(destination) != 3:
        messages.error(request, 'Kode kota harus 3 huruf (contoh: CGK, DPS)')
        return redirect('search_flight')
    
    # Simpan data pencarian di session
    request.session['search_params'] = {
        'origin': origin.upper(),
        'destination': destination.upper(),
        'departure_date': departure_date,
        'return_date': return_date if trip_type == 'roundtrip' else None,
        'trip_type': trip_type
    }
    
    # Panggil Amadeus API
    amadeus = AmadeusAPI()
    results = amadeus.search_flights(
        origin=origin,
        destination=destination,
        departure_date=departure_date,
        return_date=return_date if trip_type == 'roundtrip' else None
    )
    
    if 'error' in results:
        messages.error(request, f'Terjadi kesalahan: {results["error"]}')
        return redirect('search_flight')
    
    if 'data' not in results or not results['data']:
        messages.warning(request, 'Tidak ada penerbangan yang ditemukan untuk pencarian Anda')
        return redirect('search_flight')
    
    # Proses data untuk ditampilkan
    flights = []
    for idx, offer in enumerate(results.get('data', [])):
        try:
            # Ambil informasi penerbangan pertama (outbound)
            itinerary = offer['itineraries'][0]
            segments = itinerary['segments']
            first_segment = segments[0]
            last_segment = segments[-1]
            
            # Hitung durasi total
            duration = itinerary.get('duration', 'N/A')
            if duration.startswith('PT'):
                duration = duration[2:].replace('H', 'j ').replace('M', 'm')
            
            # Ambil informasi maskapai
            carrier_code = first_segment['carrierCode']
            
            # Hitung jumlah transit
            stops = len(segments) - 1
            
            # Format harga
            price = offer['price']['total']
            currency = offer['price']['currency']
            
            flight_info = {
                'id': idx,
                'offer_data': json.dumps(offer),
                'carrier': carrier_code,
                'flight_number': f"{first_segment['carrierCode']}{first_segment['number']}",
                'departure_time': first_segment['departure']['at'],
                'arrival_time': last_segment['arrival']['at'],
                'departure_airport': first_segment['departure']['iataCode'],
                'arrival_airport': last_segment['arrival']['iataCode'],
                'duration': duration,
                'stops': stops,
                'price': price,
                'currency': currency,
                'seats_available': offer.get('numberOfBookableSeats', 'N/A')
            }
            
            flights.append(flight_info)
        except (KeyError, IndexError) as e:
            print(f"Error processing flight offer: {str(e)}")
            continue
    
    context = {
        'flights': flights,
        'search_params': request.session.get('search_params', {})
    }
    
    return render(request, 'flight_results.html', context)

def flight_booking(request):
    """Halaman booking penerbangan"""
    if request.method == 'POST':
        # Proses pemesanan
        passenger_name = request.POST.get('passenger_name', '').strip()
        passport_number = request.POST.get('passport_number', '').strip()
        email = request.POST.get('email', '').strip()
        flight_data = request.POST.get('flight_data', '')
        
        if not all([passenger_name, passport_number, flight_data]):
            messages.error(request, 'Mohon lengkapi semua data penumpang')
            return redirect('flight_booking')
        
        try:
            # Parse flight data
            flight_offer = json.loads(flight_data)
            search_params = request.session.get('search_params', {})
            
            # Split nama untuk first name dan last name
            name_parts = passenger_name.split(' ', 1)
            first_name = name_parts[0]
            last_name = name_parts[1] if len(name_parts) > 1 else name_parts[0]
            
            # Simpan booking ke database
            booking = Booking.objects.create(
                booking_reference=str(uuid.uuid4())[:8].upper(),
                passenger_name=passenger_name,
                passport_number=passport_number,
                origin=search_params.get('origin', ''),
                destination=search_params.get('destination', ''),
                departure_date=search_params.get('departure_date', ''),
                return_date=search_params.get('return_date'),
                flight_data=flight_offer,
                total_price=flight_offer['price']['total'],
                currency=flight_offer['price']['currency'],
                status='confirmed'
            )
            
            # Simpan booking reference di session
            request.session['booking_reference'] = booking.booking_reference
            
            messages.success(request, f'Booking berhasil! Referensi booking Anda: {booking.booking_reference}')
            return redirect('booking_confirmation')
            
        except json.JSONDecodeError:
            messages.error(request, 'Data penerbangan tidak valid')
            return redirect('search_flight')
        except Exception as e:
            messages.error(request, f'Terjadi kesalahan: {str(e)}')
            return redirect('flight_booking')
    
    # GET request
    flight_index = request.GET.get('flight')
    if flight_index is None:
        messages.error(request, 'Silakan pilih penerbangan terlebih dahulu')
        return redirect('search_flight')
    
    # Ambil data dari session (dari hasil pencarian sebelumnya)
    search_params = request.session.get('search_params', {})
    
    # Ambil data penerbangan yang dipilih
    selected_flight = request.GET.get('flight_data')
    if not selected_flight:
        messages.error(request, 'Data penerbangan tidak ditemukan')
        return redirect('search_flight')
    
    try:
        flight_offer = json.loads(selected_flight)
        
        # Parse informasi penerbangan
        itinerary = flight_offer['itineraries'][0]
        segments = itinerary['segments']
        first_segment = segments[0]
        last_segment = segments[-1]
        
        context = {
            'flight': {
                'carrier': first_segment['carrierCode'],
                'flight_number': f"{first_segment['carrierCode']}{first_segment['number']}",
                'departure_time': first_segment['departure']['at'],
                'arrival_time': last_segment['arrival']['at'],
                'departure_airport': first_segment['departure']['iataCode'],
                'arrival_airport': last_segment['arrival']['iataCode'],
                'duration': itinerary.get('duration', 'N/A').replace('PT', '').replace('H', 'j ').replace('M', 'm'),
                'price': flight_offer['price']['total'],
                'currency': flight_offer['price']['currency'],
            },
            'flight_data': selected_flight,
            'search_params': search_params
        }
        
        return render(request, 'flight_booking.html', context)
        
    except (json.JSONDecodeError, KeyError, IndexError) as e:
        messages.error(request, f'Data penerbangan tidak valid: {str(e)}')
        return redirect('search_flight')

def booking_confirmation(request):
    """Halaman konfirmasi booking"""
    booking_reference = request.session.get('booking_reference')
    
    if not booking_reference:
        messages.error(request, 'Booking tidak ditemukan')
        return redirect('search_flight')
    
    try:
        booking = Booking.objects.get(booking_reference=booking_reference)
        
        # Parse flight data
        flight_data = booking.flight_data
        itinerary = flight_data['itineraries'][0]
        segments = itinerary['segments']
        first_segment = segments[0]
        last_segment = segments[-1]
        
        context = {
            'booking': booking,
            'flight_info': {
                'carrier': first_segment['carrierCode'],
                'flight_number': f"{first_segment['carrierCode']}{first_segment['number']}",
                'departure_time': first_segment['departure']['at'],
                'arrival_time': last_segment['arrival']['at'],
                'departure_airport': first_segment['departure']['iataCode'],
                'arrival_airport': last_segment['arrival']['iataCode'],
            }
        }
        
        return render(request, 'booking_confirmation.html', context)
        
    except Booking.DoesNotExist:
        messages.error(request, 'Booking tidak ditemukan')
        return redirect('search_flight')